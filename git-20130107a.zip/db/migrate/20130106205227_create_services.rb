class CreateServices < ActiveRecord::Migration
end
